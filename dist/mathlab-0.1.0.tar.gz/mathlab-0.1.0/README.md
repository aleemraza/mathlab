# mathlab
mathlab is a lightweight Python library that provides essential math utilities. It is designed for beginners learning Python, as well as developers who want a simple, easy-to-use math helper library without relying on heavy dependencies.
